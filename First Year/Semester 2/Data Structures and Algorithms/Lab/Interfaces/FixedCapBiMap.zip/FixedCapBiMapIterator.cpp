#include "FixedCapBiMap.h"
#include "FixedCapBiMapIterator.h"
#include <exception>
using namespace std;


FixedCapBiMapIterator::FixedCapBiMapIterator(const FixedCapBiMap& d) : map(d)
{
	//TODO - Implementation
}


void FixedCapBiMapIterator::first() {
	//TODO - Implementation
}


void FixedCapBiMapIterator::next() {
	//TODO - Implementation
}


TElem FixedCapBiMapIterator::getCurrent(){
	//TODO - Implementation
	return NULL_TELEM;
}


bool FixedCapBiMapIterator::valid() const {
	//TODO - Implementation
	return false;
}



