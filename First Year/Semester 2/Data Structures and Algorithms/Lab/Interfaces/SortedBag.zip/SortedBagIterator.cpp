#include "SortedBagIterator.h"
#include "SortedBag.h"
#include <exception>

using namespace std;

SortedBagIterator::SortedBagIterator(const SortedBag& b) : bag(b) {
	//TODO - Implementation
}

TComp SortedBagIterator::getCurrent() {
	//TODO - Implementation
	return NULL_TCOMP;
}

bool SortedBagIterator::valid() {
	//TODO - Implementation
	return false;
}

void SortedBagIterator::next() {
	//TODO - Implementation
}

void SortedBagIterator::first() {
	//TODO - Implementation
}

