#include "GUI.h"
#include <qlayout.h>
#include <qlabel.h>

GUI::GUI(Service& serv): serv{serv}
{
	this->buildGUI();
	this->populateList();

	QObject::connect(this->addButton, &QPushButton::clicked, this, &GUI::addButtonHandler);
}

void GUI::buildGUI()
{
	QHBoxLayout* mainLayout = new QHBoxLayout{ this };
	this->spaceshipListWidget = new QListWidget{};
	mainLayout->addWidget(spaceshipListWidget);

	QGridLayout* rightLayout = new QGridLayout{};

	QLabel* nameLabel = new QLabel{ "Name" };
	this->nameEdit = new QLineEdit{};
	QLabel* captainLabel = new QLabel{ "Captain" };
	this->captainEdit = new QLineEdit{};
	QLabel* typeLabel = new QLabel{ "Type" };
	this->typeEdit = new QLineEdit{};

	rightLayout->addWidget(nameLabel, 0, 0);
	rightLayout->addWidget(this->nameEdit, 0, 1);
	rightLayout->addWidget(captainLabel, 1, 0);
	rightLayout->addWidget(this->captainEdit, 1, 1);
	rightLayout->addWidget(typeLabel, 2, 0);
	rightLayout->addWidget(this->typeEdit, 2, 1);

	this->addButton = new QPushButton{ "Add" };
	this->deleteButton = new QPushButton{ "Delete" };

	rightLayout->addWidget(this->addButton, 3, 0);
	rightLayout->addWidget(this->deleteButton, 3, 1);

	mainLayout->addLayout(rightLayout);
}

void GUI::populateList()
{
	this->spaceshipListWidget->clear();
	
	for (auto s : this->serv.getAll())
	{
		this->spaceshipListWidget->addItem(QString::fromStdString(s.getName()));
	
		/*QListWidgetItem* item = new QListWidgetItem{ QString::fromStdString(s.getName() + " " + s.getCaptain() + " " + s.getType())};
		QFont font{ "Verdana", 20, 10 };
		item->setFont(font);
		this->spaceshipListWidget->addItem(item);*/
	}
}

void GUI::addButtonHandler()
{
	QString name = this->nameEdit->text();
	QString captain = this->captainEdit->text();
	QString type = this->typeEdit->text();
	this->serv.add(name.toStdString(), captain.toStdString(), type.toStdString());
	this->populateList();
}
