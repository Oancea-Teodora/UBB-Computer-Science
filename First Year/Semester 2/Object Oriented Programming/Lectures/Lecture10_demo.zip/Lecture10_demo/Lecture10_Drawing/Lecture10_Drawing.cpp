#include "Lecture10_Drawing.h"

Lecture10_Drawing::Lecture10_Drawing(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture10_Drawing::~Lecture10_Drawing()
{}
