#include "Lecture10_introspection_example.h"

Lecture10_introspection_example::Lecture10_introspection_example(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}

Lecture10_introspection_example::~Lecture10_introspection_example()
{}
