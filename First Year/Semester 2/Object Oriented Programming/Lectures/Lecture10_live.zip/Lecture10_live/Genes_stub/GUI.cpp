#include "GUI.h"
#include <QMessageBox>

GUI::GUI(std::vector<Gene> genes, QWidget *parent)
	: QWidget(parent), genes{genes}
{
	ui.setupUi(this);
	this->populateList();
	this->connectSignalsAndSlots();
}

GUI::~GUI()
{}

void GUI::connectSignalsAndSlots()
{
	QObject::connect(this->ui.genesListWidget, &QListWidget::itemClicked,
		this, &GUI::itemClickedHandler);

	QObject::connect(this->ui.deleteButton, &QPushButton::clicked,
		this, &GUI::deleteButtonHandler);

	QObject::connect(this->ui.addButton, &QPushButton::clicked,
		this, [&]() {
			QString name = this->ui.nameLineEdit->text();
			QString orgName = this->ui.organismLineEdit->text();
			QString sequence = this->ui.sequenceLineEdit->text();
			Gene g{ name.toStdString(), orgName.toStdString(), sequence.toStdString()};
			genes.push_back(g);
			populateList();
		});
}

void GUI::populateList()
{
	this->ui.genesListWidget->clear();

	for (Gene g : this->genes)
	{
		this->ui.genesListWidget->addItem(QString::fromStdString(g.getOrganismName() + " - " + g.getName()));
	}
}

int GUI::getSelectedIndex()
{
	if (this->ui.genesListWidget->count() == 0)
		return -1;

	// current row will return the selected index only in certain situations (in the current one, it will)
	// return this->ui.genesListWidget->currentRow();

	// get selected index
	QModelIndexList index = this->ui.genesListWidget->selectionModel()->selectedIndexes();
	if (index.size() == 0)
		return -1;

	int idx = index.at(0).row();
	return idx;
}

void GUI::itemClickedHandler()
{
	int row = this->getSelectedIndex();
	if (row == -1)
	{
		this->ui.organismLineEdit->clear();
		this->ui.nameLineEdit->clear();
		this->ui.sequenceLineEdit->clear();
		return;
	}

	Gene g = genes[row];
	this->ui.organismLineEdit->setText(QString::fromStdString(g.getOrganismName()));
	this->ui.nameLineEdit->setText(QString::fromStdString(g.getName()));
	this->ui.sequenceLineEdit->setText(QString::fromStdString(g.getSequence()));
}

void GUI::deleteButtonHandler()
{
	int row = this->getSelectedIndex();
	if (row == -1)
	{
		QMessageBox::warning(nullptr, "Error", "Please select a gene to be deleted!");
		return;
	}
	genes.erase(genes.begin() + row);
	this->populateList();
}
