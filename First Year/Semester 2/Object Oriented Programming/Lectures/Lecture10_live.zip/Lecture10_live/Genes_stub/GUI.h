#pragma once

#include <QWidget>
#include "ui_GUI.h"
#include "Gene.h"

class GUI : public QWidget
{
	Q_OBJECT


private:
	std::vector<Gene> genes;

public:
	GUI(std::vector<Gene> genes, QWidget *parent = nullptr);
	~GUI();

private:
	Ui::GUIClass ui;

	void connectSignalsAndSlots();

	void populateList();
	int getSelectedIndex();
	void itemClickedHandler();
	void deleteButtonHandler();
};
