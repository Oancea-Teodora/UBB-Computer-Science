#include "DynamicArray.h"
#include <stdlib.h>

DynamicArray* createDynamicArray(int capacity, destroyFunction op)
{
	DynamicArray* arr = (DynamicArray*)malloc(sizeof(DynamicArray));
	if (arr == NULL)
		return NULL;
	arr->capacity = capacity;
	arr->size = 0;
	arr->elems = (TElem*)malloc(sizeof(TElem) * capacity);
	if (arr->elems == NULL)
	{
		free(arr);
		return NULL;
	}
	arr->destroyOp = op;
	return arr;
}

void destroyDynamicArray(DynamicArray* arr)
{
	if (arr == NULL)
		return;
	for (int i = 0; i < arr->size; i++)
		arr->destroyOp(arr->elems[i]);
	free(arr->elems);
	free(arr);
}

void resize(DynamicArray* arr)
{
	if (arr == NULL)
		return;
	arr->capacity *= 2;
	TElem* aux = (TElem*)realloc(arr->elems, sizeof(TElem) * arr->capacity);
	if (aux == NULL)
		return;
	arr->elems = aux;
}

void addElemToArray(DynamicArray* arr, TElem elem)
{
	if (arr == NULL)
		return;
	if (arr->size == arr->capacity)
		resize(arr);
	arr->elems[arr->size++] = elem;
}

int getSize(DynamicArray* arr)
{
	if (arr == NULL)
		return 0;
	return arr->size;
}
