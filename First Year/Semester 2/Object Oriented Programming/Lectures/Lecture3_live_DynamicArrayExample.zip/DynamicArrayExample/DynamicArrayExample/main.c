#include <crtdbg.h>
#include "DynamicArray.h"
#include <assert.h>

int main()
{
	DynamicArray* arrPlanets = createDynamicArray(2,&destroyPlanet);

	Planet* p1 = createPlanet("Earth", "terrestrial", 0);
	Planet* p2 = createPlanet("Jupiter", "gas", 5);
	Planet* p3 = createPlanet("Saturn", "gas", 8);

	addElemToArray(arrPlanets, p1);
	addElemToArray(arrPlanets, p2);
	addElemToArray(arrPlanets, p3);

	assert(getSize(arrPlanets) == 3);

	//destroyDynamicArray(arrPlanets);

	DynamicArray* arrayArrays = createDynamicArray(2, &destroyDynamicArray);
	addElemToArray(arrayArrays, arrPlanets);

	destroyDynamicArray(arrayArrays);

	_CrtDumpMemoryLeaks();
	return 0;
}