#pragma once

#include "Planet.h"

typedef void* TElem;
typedef void (*destroyFunction)(TElem);

typedef struct
{
	int size, capacity;
	TElem* elems;
	destroyFunction destroyOp;
} DynamicArray;

DynamicArray* createDynamicArray(int capacity, destroyFunction op);
void destroyDynamicArray(DynamicArray* arr);
void addElemToArray(DynamicArray* arr, TElem elem);
int getSize(DynamicArray* arr);